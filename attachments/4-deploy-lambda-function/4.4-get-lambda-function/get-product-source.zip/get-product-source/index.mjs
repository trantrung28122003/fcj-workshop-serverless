import { DynamoDBClient, ScanCommand, GetItemCommand } from "@aws-sdk/client-dynamodb";

const REGION     = "ap-southeast-1";
const TABLE_NAME = "Product";

const CORS_HEADERS = {
  "Access-Control-Allow-Origin":  "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization"
};

const db = new DynamoDBClient({ region: REGION });

export const handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: CORS_HEADERS, body: "" };
  }

  if (event.httpMethod !== "GET") {
    return {
      statusCode: 405,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: `Method ${event.httpMethod} not allowed` })
    };
  }

  const id = event.pathParameters?.id;

  try {
    if (id) {
      // --- GET /products/{id} ---
      const { Item } = await db.send(new GetItemCommand({
        TableName: TABLE_NAME,
        Key: { Id: { S: id } }
      }));
      if (!Item) {
        return {
          statusCode: 404,
          headers: CORS_HEADERS,
          body: JSON.stringify({ error: "Product not found" })
        };
      }
      const product = {
        id:          Item.Id.S,
        name:        Item.Name.S,
        price:       parseFloat(Item.Price.N),
        stockCount:  parseInt(Item.StockCount.N, 10),
        imageUrl:    Item.ImageUrl.S,
        description: Item.Description.S,
        categoryId:  parseInt(Item.CategoryId.N, 10)
      };
      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify(product)
      };
    } else {
      // --- GET /products ---
      const { Items = [] } = await db.send(new ScanCommand({
        TableName: TABLE_NAME
      }));
      const products = Items.map(item => ({
        id:          item.Id.S,
        name:        item.Name.S,
        price:       parseFloat(item.Price.N),
        stockCount:  parseInt(item.StockCount.N, 10),
        imageUrl:    item.ImageUrl.S,
        description: item.Description.S,
        categoryId:  parseInt(item.CategoryId.N, 10)
      }));
      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify(products)
      };
    }
  } catch (err) {
    console.error("Get/List Products error:", err);
    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: err.message || "Internal Server Error" })
    };
  }
};
