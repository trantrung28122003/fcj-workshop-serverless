import { DynamoDBClient, GetItemCommand, DeleteItemCommand } from "@aws-sdk/client-dynamodb";

const REGION     = "ap-southeast-1";
const TABLE_NAME = "Category";

const db = new DynamoDBClient({ region: REGION });

const CORS_HEADERS = {
  "Access-Control-Allow-Origin":  "*",
  "Access-Control-Allow-Methods": "DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization"
};

export const handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: CORS_HEADERS, body: "" };
  }

  if (event.httpMethod !== "DELETE") {
    return {
      statusCode: 405,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: `Method ${event.httpMethod} not allowed` })
    };
  }

  const id = event.pathParameters?.id;
  if (!id) {
    return {
      statusCode: 400,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: "Missing category id in path" })
    };
  }

  try {
    const { Item } = await db.send(new GetItemCommand({
      TableName: TABLE_NAME,
      Key:       { Id: { S: id } },
      ProjectionExpression: "Id"
    }));
    if (!Item) {
      return {
        statusCode: 404,
        headers: CORS_HEADERS,
        body: JSON.stringify({ error: "Category not found" })
      };
    }
  } catch (err) {
    console.error("Error fetching category for delete:", err);
    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: "Failed to verify category existence" })
    };
  }

  try {
    await db.send(new DeleteItemCommand({
      TableName: TABLE_NAME,
      Key:       { Id: { S: id } }
    }));
  } catch (err) {
    console.error("Error deleting category record:", err);
    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: "Failed to delete category" })
    };
  }

  return {
    statusCode: 200,
    headers: CORS_HEADERS,
    body: JSON.stringify({
      message: "Category deleted",
      id
    })
  };
};
